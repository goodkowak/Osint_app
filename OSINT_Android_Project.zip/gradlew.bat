@echo off
echo Gradle wrapper placeholder
gradle %*
