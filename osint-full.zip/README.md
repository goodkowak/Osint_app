OSINT Helper - APK Starter (Kivy)

This is a minimal starter Kivy app for Android (APK). It provides:
 - simple UI to store an API Key locally
 - a local 'Search' UI that currently shows stubbed results
 - a buildozer.spec to build an APK

I cannot build the APK in this environment, but this project is ready-to-build.
Options to build:
 - Locally on Linux using Buildozer (recommended)
 - Use GitHub Actions on push (workflow included)
 - Ask a friend/host to run buildozer and produce the APK

See build instructions in the README for commands.
