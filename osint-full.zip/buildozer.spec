[app]
title = OSINT Helper
package.name = osinthelper
package.domain = org.example
source.include_exts = py,png,jpg,json,kv
version = 0.1
requirements = python3,kivy,requests
orientation = portrait
android.permissions = INTERNET,WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE
