from kivy.app import App
from kivy.lang import Builder
from kivy.uix.popup import Popup
from kivy.uix.label import Label
import json, os

KV = '''
BoxLayout:
    orientation: 'vertical'
    padding: 12
    spacing: 12

    BoxLayout:
        size_hint_y: None
        height: '40dp'
        Label:
            text: 'OSINT Helper'
            font_size: '18sp'
    BoxLayout:
        size_hint_y: None
        height: '40dp'
        TextInput:
            id: api_key
            hint_text: 'API Key (stored locally)'
            text: app.config_get('api_key') or ''
        Button:
            text: 'Save'
            size_hint_x: None
            width: '80dp'
            on_release: app.save_api_key(api_key.text)

    BoxLayout:
        size_hint_y: None
        height: '40dp'
        TextInput:
            id: target
            hint_text: 'Enter domain, ip, or query'
        Button:
            text: 'Search'
            size_hint_x: None
            width: '100dp'
            on_release: app.do_search(target.text)

    ScrollView:
        GridLayout:
            id: results_box
            cols: 1
            size_hint_y: None
            height: self.minimum_height
            row_default_height: '30dp'
            row_force_default: False
'''

class OSINTApp(App):
    CONFIG_FILE = 'osint_config.json'

    def build(self):
        self.title = 'OSINT Helper'
        self.root = Builder.load_string(KV)
        return self.root

    def config_get(self, key):
        try:
            if not os.path.exists(self.CONFIG_FILE):
                return None
            with open(self.CONFIG_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return data.get(key)
        except Exception:
            return None

    def save_api_key(self, key):
        data = {}
        if os.path.exists(self.CONFIG_FILE):
            try:
                with open(self.CONFIG_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            except Exception:
                data = {}
        data['api_key'] = key
        with open(self.CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f)
        self.show_popup('Saved', 'API Key saved locally (only on this device).')

    def show_popup(self, title, text):
        p = Popup(title=title, content=Label(text=text), size_hint=(0.8, 0.4))
        p.open()

    def do_search(self, query):
        box = self.root.ids.results_box
        box.clear_widgets()
        if not query:
            self.show_popup('Error', 'Please enter a search query.')
            return
        api_key = self.config_get('api_key') or '(no api key)'
        results = [
            f'Query: {query}',
            f'Using API Key: {api_key[:6] + "..." if len(api_key)>6 else api_key}',
            'Note: This is a local stub. In full app, this launches the OSINT pipeline (whois, dns, crtsh, shodan...)',
            'To enable external lookups, add API keys in the API Key field and rebuild with network permissions.'
        ]
        for r in results:
            box.add_widget(Label(text=r))
        self.show_popup('Done', 'Search completed (local preview).')

if __name__ == '__main__':
    OSINTApp().run()
