# Placeholder for OSINT search pipeline to be implemented for Android builds.
def run_pipeline(query):
    return {'status':'stub', 'query': query}
