#!/usr/bin/env bash
# Simple runner for testing (requires python and kivy installed)
PY=python3
echo "Running OSINT Helper (local run). For a real APK install, build with buildozer."
$PY main.py
